
By executing ant in the parent directory it will try to obtain those files if they're missing

----

The following libraries are taken from Jemmy distribution page http://jemmy.java.net/dist/

JemmyCore.jar
JemmyAWTInput.jar

----

The following libraries are taken from SQE tests repository http://shaman.russia.sun.com/hg/index.cgi/java-client-2.0/

GlassImage.jar
GlassRobot.jar
JemmyFX.jar